//
//  ViewController.swift
//  chan8786_a1
//
//  Created by Jonatham Chang on 2022-01-17.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answerLabel: UILabel!
    
//    global variables
    struct i {
        var index: Int
    }
    var index = i(index: 0)
    
    let questions = ["What is your name?",
                     "What is your favorite sport?",
                     "What is your hobby?",
                     "Where are you from?"]
    
    let answers = ["Jonatham Chang", "Swimming", "Gaming", "Myanmar (Burma)"]
    
    let imageNames = ["self_portrait.jpeg", "swimming.jepg", "gaming.jepg", "burma.jepg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.

        
//        adding first image
        imageView.image = UIImage(named: imageNames[index.index])
//        adding first question
        questionLabel.text = questions[index.index]
    }


    @IBAction func ShowAnswerClicked(_ sender: Any) {
        print("Show Answer button clicked")
        answerLabel.text = answers[index.index]
    }
    
    @IBAction func NextClicked(_ sender: Any) {
        print("Next button clicked")
        index.index += 1
        print(index.index)
        if index.index > 3 {
            index.index = 0
        }
        
        imageView.image = UIImage(named: imageNames[index.index])
        questionLabel.text = questions[index.index]
        answerLabel.text = "-----"
        
    }
}

